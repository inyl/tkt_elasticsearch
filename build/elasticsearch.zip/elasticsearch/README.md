# tkt_elasticsearch

twitter korean text elasticsesarch plugin


[twitter korean text](https://github.com/twitter/twitter-korean-text)를 elasticsearch에서 쓸 수 있게 만든 플러그인입니다.


기존에 존재하던 [tkt_elasticsearch](https://github.com/socurites/tkt-elasticsearch)
는 구버전에만 호환되어 elasticsearch 최신버전과 호환되게 수정하였습니다.

호환표와 버전은 다음을 참조 해주세요

<작성중>

## 설치방법

## 테스트


<작성중>

## 버전 변경방법 (rebuild)
